Odishi(TM)
(c)1997, Digital Empires Inc.. All rights reserved.
Freeware version

Odishi took a while to create. The process
involved corel draw for the bare bones part of
the font, then Fontographer was use to make the
font accurate and uniform. Kerning and spacing were
used. This is a full feature type. We generated
Adobe type1 and True Type. Again, we only made them
available in the Windows format, for now. We intend
to explore the tectonics to generate Mac font formats
Although these are some of the first fonts coming
out of Digital Empires Fontware foundry, we intend
on improving them. Don't you just love updates
and patches.

Odishi(TM) is a strong and sexy type. A while back
I commissioned some artwork for an idea of nasty
or bad girls. A really strong n' hot babe needs a
strong n' sexy type.

Odishi (TM) is shareware. If you like, keep it,
and use this font, please check out our web page at
WWW.DigitalEmpires.com for pricing (the font will
probably never be more than $10).

Feel free to share this font with others,
but please include this documentation.

Thanks,

Steve

email: Webmaster@DigitalEmpires.com
